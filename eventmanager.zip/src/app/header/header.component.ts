import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormioAuthService } from 'angular-formio/auth';
import { FormioForm } from 'angular-formio';
import { FormBuilderComponent } from 'angular-formio';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass']
})
export class HeaderComponent implements OnInit {

  constructor(private auth: FormioAuthService) { }

  ngOnInit() {
  }

}
