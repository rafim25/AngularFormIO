import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormioAuth, FormioAuthRoutes } from 'angular-formio/auth';
// import { FormioAppConfig ,FormBuilderComponent,FormioModule} from 'angular-formio';

@NgModule({
  declarations: [
  ],
  imports: [
    // FormioModule,
    CommonModule,
    FormioAuth,
    RouterModule.forChild(FormioAuthRoutes())
  ]
})
export class AuthModule { }
